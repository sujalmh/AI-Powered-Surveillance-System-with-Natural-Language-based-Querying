INDICON 2026 submission source
================================

Files
-----
INDICON2026Conference.tex  paper source (8 pages, IEEEtran conference class)
References.bib             bibliography (IEEEtran style)
IEEEtran.cls              class file shipped with the INDICON 2026 author kit
README.txt                this file

Rebuild (pdfLaTeX + BibTeX, run from this directory)
----------------------------------------------------
    pdflatex -interaction=nonstopmode INDICON2026Conference.tex
    bibtex   INDICON2026Conference
    pdflatex -interaction=nonstopmode INDICON2026Conference.tex
    pdflatex -interaction=nonstopmode INDICON2026Conference.tex

The fourth pass settles the cross references, so do not stop after the first
one.  latexmk does the same in a single command (it needs perl on Windows):

    latexmk -pdf INDICON2026Conference.tex

Expected result
---------------
The build must end with

    Output written on INDICON2026Conference.pdf (8 pages, ...)

and the log must contain neither an undefined reference/citation nor an
"Overfull \hbox" warning.  backend/scripts/package_submission.py and
backend/scripts/check_release.py enforce both, so a submission that does not
rebuild into a clean 8-page PDF is rejected before it leaves the repository.

The paper contains no external image files: the dataflow figure is a TikZ
picture inside the .tex source.  The only companion files needed are the two
shipped here (References.bib and IEEEtran.cls).

Paper ID: 850
