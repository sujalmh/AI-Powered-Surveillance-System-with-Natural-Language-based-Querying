INDICON 2026 submission source
================================

Files
-----
INDICON2026Conference.tex  paper source (8 pages, IEEEtran conference class)
References.bib             bibliography (15 entries, IEEEtran style)
IEEEtran.cls              class file shipped with the INDICON 2026 author kit

Compile (pdfLaTeX + BibTeX, run from this directory)
----------------------------------------------------
    pdflatex -interaction=nonstopmode INDICON2026Conference.tex
    bibtex   INDICON2026Conference
    pdflatex -interaction=nonstopmode INDICON2026Conference.tex
    pdflatex -interaction=nonstopmode INDICON2026Conference.tex

The paper contains no external image files: the dataflow figure is a TikZ
picture inside the .tex source.

Paper ID: 850
