INDICON 2026 submission package
===============================

Files
-----
INDICON2026_850.pdf         the camera-ready paper (8 pages, 2-column IEEEtran)
INDICON2026_850_source.zip  the LaTeX source bundle (.tex, .bib, IEEEtran.cls,
                            README.txt with the exact rebuild sequence)
INDICON2026Conference.tex   the paper source (same file as in the source bundle)
References.bib              the bibliography
IEEEtran.cls                class file shipped with the INDICON 2026 author kit
README.txt                  this file

The camera-ready PDF is generated from INDICON2026Conference.tex with
pdfLaTeX + BibTeX; see README.txt inside INDICON2026_850_source.zip for the
exact command sequence and for the checks the build has to pass (8 pages, no
undefined references, no "Overfull \hbox").

Paper ID: 850
